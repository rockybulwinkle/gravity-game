/*
 * music.c
 *
 *  Created on: Mar 9, 2011
 *      Author: hopwoocp
 */

#include "sound.h"
#include <asndlib.h>
#include <mp3player.h>
void loadSounds(){
	ASND_Init();
//MP3Player_
}

/*
 * bloom.c
 *
 *  Created on: Apr 1, 2011
 *      Author: hopwoocp
 */
#include <fat.h>
#include <stdio.h>
#include <stdlib.h>
#include <grrlib.h>
#include "bloom.h"
#include "../sdcardMount.h"

int bloom = 1;
guVector screen_quad[4] = { { 0, 0, 0 }, { 640, 0, 0 }, { 640, 480, 0 }, { 0,
		480, 0 } };

static u8 avg_table[BLOOM_STACK_LOOKUP_SIZE];
struct comp_s {
	u8 r, g, b, a;
}__attribute__ ((packed));

typedef union {
	struct comp_s comp;
	u32 rgba;
} rgbaPixel_u;

static rgbaPixel_u temp[BLOOM_TEX_WIDTH * BLOOM_TEX_HEIGHT]; // Stack blur temp buffer

// Modified version of GRRLIB_GetPixelFromtexImg(). Returns 0 if the grayscale value
// of the pixel is less than BLOOM_THRESHOLD.
static inline u32 _GetPixel(const int x, const int y, const GRRLIB_texImg *tex) {
	register u32 offs;
	register u32 ar;
	register u8* bp = (u8*) tex->data;

	offs = (((y & (~3)) << 2) * tex->w) + ((x & (~3)) << 4) + ((((y & 3) << 2)
			+ (x & 3)) << 1);
	ar = (u32) (*((u16*) (bp + offs)));
	rgbaPixel_u
			pixel = {
					.rgba = (ar<<24) | ( ((u32)(*((u16*)(bp+offs+32)))) <<8) | (ar>>8) };

	u32 gray = ((pixel.comp.r * 11) + (pixel.comp.g * 16) + (pixel.comp.b * 5))
			/ 32;
	if (gray > BLOOM_THRESHOLD) {
		return pixel.rgba;
	}
	return 0;
}

// initialize the bloom stuff

void initializeBloom() {
	tex_bloom = GRRLIB_CreateEmptyTexture(BLOOM_TEX_WIDTH, BLOOM_TEX_HEIGHT );
	tex_screen = GRRLIB_CreateEmptyTexture(rmode->fbWidth, rmode->efbHeight);
	u32 i;
	for (i = 0; i < BLOOM_STACK_LOOKUP_SIZE; ++i) {
		avg_table[i] = (u8) ((i / (float) BLOOM_RADIUS) + 0.5);
	}

	FILE * file = fopen("sd:/hello.txt", "a");
	if (file == NULL) {
		exit(0);
	}
	fprintf(file, "tex_bloom's width, height: %d, %d\n", BLOOM_TEX_WIDTH,
			BLOOM_TEX_HEIGHT);
	fprintf(file, "tex_screen's width, height: %d, %d\n", rmode->fbWidth,
			rmode->efbHeight);
	fclose(file);

}

void doBloom() {
	if (bloom == true) {
		// Capture the rendered scene to a texture
		GRRLIB_Screen2Texture(0, 0, tex_screen, false);
		FILE * file = fopen("sd:/hello.txt", "a");
		if (file == NULL)
			exit(0);

		u32 w, h, r, g, b, i;
		rgbaPixel_u read, write;

		// Horizontal scale and blur each row into the temp buffer
		for (h = 0; h < BLOOM_TEX_HEIGHT; ++h) {
			// Build the initial stack and calculate the first pixel
			if ((h * BLOOM_WIDTH_SCALE) + 1 >= rmode->fbWidth) {
				fprintf(file, "cond1\n");
				fclose(file);
				DeInitSD();
				exit(0);
			}
			read.rgba = _GetPixel((0 * BLOOM_HEIGHT_SCALE) + 1, (h
					* BLOOM_WIDTH_SCALE) + 1, tex_screen);
			r = read.comp.r * BLUR_STACK_LEFT;
			g = read.comp.g * BLUR_STACK_LEFT;
			;
			b = read.comp.b * BLUR_STACK_LEFT;
			;

			for (i = 1; i < BLUR_STACK_RIGHT; ++i) {
				if ((i * BLOOM_HEIGHT_SCALE) + 1 >= rmode->fbWidth || (h
						* BLOOM_HEIGHT_SCALE) >= rmode->efbHeight) {
					fprintf(file, "cond2\n");
					fprintf(file, "%d %d", (i * BLOOM_HEIGHT_SCALE) + 1, h
							* BLOOM_HEIGHT_SCALE);
					fclose(file);
					DeInitSD();
					exit(0);
				}
				read.rgba = _GetPixel((i * BLOOM_HEIGHT_SCALE) + 1, (h
						* BLOOM_HEIGHT_SCALE), tex_screen);
				r += read.comp.r;
				g += read.comp.g;
				b += read.comp.b;
			}
			if (r >= BLOOM_STACK_LOOKUP_SIZE || g >= BLOOM_STACK_LOOKUP_SIZE
					|| b >= BLOOM_STACK_LOOKUP_SIZE || r < 0 || g < 0 || b < 0) {
				fprintf(file, "cond7\n");
				fclose(file);
				DeInitSD();
				exit(0);
			}
			write.comp.r = r >= 0 ? avg_table[r] : avg_table[0];
			write.comp.g = g >= 0 ? avg_table[g] : avg_table[0];
			write.comp.b = b >= 0 ? avg_table[b] : avg_table[0];
			write.comp.a = BLOOM_ALPHA;
			if ((h * BLOOM_TEX_WIDTH) + 0 >= BLOOM_TEX_WIDTH * BLOOM_TEX_HEIGHT) {
				fprintf(file, "cond6\n");
				fclose(file);
				DeInitSD();
				exit(0);
			}
			temp[(h * BLOOM_TEX_WIDTH) + 0] = write;

			for (w = 0; w < BLOOM_TEX_WIDTH; ++w) {

				// Pop the 'left' pixel from the stack
				if (w >= BLUR_STACK_LEFT) {
					if (((w - BLUR_STACK_LEFT) * BLOOM_HEIGHT_SCALE)
							>= rmode->fbWidth || (h * BLOOM_WIDTH_SCALE)
							>= rmode->efbHeight) {
						fprintf(file, "cond3\n");
						fclose(file);
						DeInitSD();
						exit(0);
					}
					read.rgba = _GetPixel(((w - BLUR_STACK_LEFT)
							* BLOOM_HEIGHT_SCALE), (h * BLOOM_WIDTH_SCALE),
							tex_screen);
				} else {
					if ((0 * BLOOM_HEIGHT_SCALE) + 1 >= rmode->fbWidth || (h
							* BLOOM_WIDTH_SCALE) >= rmode->efbHeight) {
						fprintf(file, "cond4\n");
						fprintf(file, "%d %d", (0 * BLOOM_HEIGHT_SCALE) + 1, (h
								* BLOOM_WIDTH_SCALE));
						fclose(file);
						DeInitSD();
						exit(0);
					}
					read.rgba = _GetPixel((0 * BLOOM_HEIGHT_SCALE) + 1, (h
							* BLOOM_WIDTH_SCALE), tex_screen);
				}
				r -= read.comp.r;
				g -= read.comp.g;
				b -= read.comp.b;

				// Push the 'right' pixel on to the stack
				if (w < BLOOM_TEX_WIDTH - 1 - BLUR_STACK_RIGHT) {
					if (((w + BLUR_STACK_RIGHT) * BLOOM_HEIGHT_SCALE)
							>= rmode->fbWidth || (h * BLOOM_WIDTH_SCALE)
							>= rmode->efbHeight) {
						fprintf(file, "cond8\n");
						fprintf(file, "%d, %d", ((w + BLUR_STACK_RIGHT)
								* BLOOM_HEIGHT_SCALE), (h * BLOOM_WIDTH_SCALE)
								+ 1);
						fclose(file);
						DeInitSD();
						exit(0);
					}
					read.rgba = _GetPixel(((w + BLUR_STACK_RIGHT)
							* BLOOM_HEIGHT_SCALE), (h * BLOOM_WIDTH_SCALE),
							tex_screen);
				} else {
					if (BLOOM_TEX_WIDTH - 1 >= rmode->fbWidth || h
							* BLOOM_HEIGHT_SCALE >= 480) {
						fprintf(file, "cond9\n");
						fprintf(file, "%d %d %d %d", BLOOM_TEX_WIDTH, (h
								* BLOOM_WIDTH_SCALE), rmode->efbHeight,
								rmode->fbWidth);
						fclose(file);
						DeInitSD();
						exit(0);
					}
					read.rgba = _GetPixel(BLOOM_TEX_WIDTH - 1, (h
							* BLOOM_HEIGHT_SCALE), tex_screen);
				}
				r += read.comp.r;
				g += read.comp.g;
				b += read.comp.b;
				//fprintf(file, "r: %d g: %d b:%d avg_table.size: %d\n", r,g,b, BLOOM_STACK_LOOKUP_SIZE);
				if (r >= BLOOM_STACK_LOOKUP_SIZE || g
						>= BLOOM_STACK_LOOKUP_SIZE || b
						>= BLOOM_STACK_LOOKUP_SIZE || r < 0 || g < 0 || b < 0) {
					//fprintf(file, "cond11\n");
					//fprintf(
					//							file,
					//							"r: %d g: %d b:%d w:%d h:%d i:%iavg_table.size: %d",
					//							r, g, b, w, h, i, BLOOM_STACK_LOOKUP_SIZE);

					//fclose(file);
					//DeInitSD();
					//exit(0);
				}
				write.comp.r = r >= 0 ? avg_table[r] : avg_table[0];
				write.comp.g = b >= 0 ? avg_table[g] : avg_table[0];
				write.comp.b = b >= 0 ? avg_table[b] : avg_table[0];
				write.comp.a = BLOOM_ALPHA;
				if ((h * BLOOM_TEX_WIDTH) + w >= BLOOM_TEX_WIDTH
						* BLOOM_TEX_HEIGHT) {
					fprintf(file, "cond10\n");
					fclose(file);
					DeInitSD();
					exit(0);
				}
				temp[(h * BLOOM_TEX_WIDTH) + w] = write;
			}
		}

		///////


		// Vertical blur the temp buffer to the bloom texture
		for (w = 0; w < BLOOM_TEX_WIDTH; ++w) {
			// Build the initial stack and calculate the first pixel;
			if ((0 * BLOOM_TEX_WIDTH) + w >= BLOOM_TEX_WIDTH * BLOOM_TEX_HEIGHT) {
				fprintf(file, "cond10\n");
				fclose(file);
				DeInitSD();
				exit(0);
			}
			read = temp[(0 * BLOOM_TEX_WIDTH) + w];
			r = read.comp.r * BLUR_STACK_LEFT;
			g = read.comp.g * BLUR_STACK_LEFT;
			b = read.comp.b * BLUR_STACK_LEFT;

			for (i = 1; i < BLUR_STACK_RIGHT + 1; ++i) {
				if ((i * BLOOM_TEX_WIDTH) + w >= BLOOM_TEX_WIDTH
						* BLOOM_TEX_HEIGHT) {
					fprintf(file, "cond12\n");
					fclose(file);
					DeInitSD();
					exit(0);
				}
				read = temp[(i * BLOOM_TEX_WIDTH) + w];
				r += read.comp.r;
				g += read.comp.g;
				b += read.comp.b;
			}
			if (r >= BLOOM_STACK_LOOKUP_SIZE || g >= BLOOM_STACK_LOOKUP_SIZE
					|| b >= BLOOM_STACK_LOOKUP_SIZE || r < 0 || g < 0 || b < 0) {
				fprintf(file, "cond13\n");
				fclose(file);
				DeInitSD();
				exit(0);
			}
			write.comp.r = r >= 0 ? avg_table[r] : avg_table[0];
			write.comp.g = g >= 0 ? avg_table[g] : avg_table[0];
			write.comp.b = b >= 0 ? avg_table[b] : avg_table[0];
			write.comp.a = BLOOM_ALPHA;

			if (w >= BLOOM_TEX_WIDTH || 1 >= BLOOM_TEX_HEIGHT) {
				fprintf(file, "cond14\n");
				fprintf(file, "w: %d h: %d\n", w, h);
				fprintf(file, "texWidth: %d texHeight: %d\n", BLOOM_TEX_WIDTH,
						BLOOM_TEX_HEIGHT);
				fclose(file);
				DeInitSD();
				exit(0);

			}
			GRRLIB_SetPixelTotexImg(w, 1, tex_bloom, write.rgba);

			for (h = 1; h < BLOOM_TEX_HEIGHT; ++h) {
				// Pop the 'top' pixel from the stack
				if (h >= BLUR_STACK_LEFT) {
					if (((h - BLUR_STACK_LEFT) * BLOOM_TEX_WIDTH) + w
							>= BLOOM_TEX_WIDTH * BLOOM_TEX_HEIGHT) {
						fprintf(file, "cond16\n");
						fclose(file);
						DeInitSD();
						exit(0);
					}
					read = temp[((h - BLUR_STACK_LEFT) * BLOOM_TEX_WIDTH) + w];
				} else {
					if ((0 * BLOOM_TEX_WIDTH) + w >= BLOOM_TEX_WIDTH
							* BLOOM_TEX_HEIGHT) {
						fprintf(file, "cond15\n");
						fclose(file);
						DeInitSD();
						exit(0);
					}
					read = temp[(0 * BLOOM_TEX_WIDTH) + w];
				}
				r -= read.comp.r;
				g -= read.comp.g;
				b -= read.comp.b;

				// Push the 'bottom' pixel on to the stack
				if (h <= BLOOM_TEX_HEIGHT - 1 - BLUR_STACK_RIGHT) {
					if (((h + BLUR_STACK_RIGHT) * BLOOM_TEX_WIDTH) + w
							>= BLOOM_TEX_WIDTH * BLOOM_TEX_HEIGHT) {
						fprintf(file, "cond17\n");
						fclose(file);
						DeInitSD();
						exit(0);
					}
					read = temp[((h + BLUR_STACK_RIGHT) * BLOOM_TEX_WIDTH) + w];
				} else {
					if (((h - BLUR_STACK_LEFT) * BLOOM_TEX_WIDTH) + w
							>= BLOOM_TEX_WIDTH * BLOOM_TEX_HEIGHT) {
						fprintf(file, "cond18\n");
						fclose(file);
						DeInitSD();
						exit(0);
					}
					read = temp[((h - BLUR_STACK_LEFT) * BLOOM_TEX_WIDTH) + w];
				}
				r += read.comp.r;
				g += read.comp.g;
				b += read.comp.b;
				if (r >= BLOOM_STACK_LOOKUP_SIZE || g
						>= BLOOM_STACK_LOOKUP_SIZE || b
						>= BLOOM_STACK_LOOKUP_SIZE || r < 0 || g < 0 || b < 0) {
					fprintf(file, "cond19\n");
					fclose(file);
					DeInitSD();
					exit(0);
				}
				write.comp.r = r >= 0 ? avg_table[r] : avg_table[0];
				write.comp.g = g >= 0 ? avg_table[g] : avg_table[0];
				write.comp.b = b >= 0 ? avg_table[b] : avg_table[0];
				write.comp.a = BLOOM_ALPHA;
				if (w >= BLOOM_TEX_WIDTH || h >= BLOOM_TEX_HEIGHT) {
					fprintf(file, "cond20\n");
					fprintf(file, "w: %d h: %d\n", w, h);
					fclose(file);
					DeInitSD();
					exit(0);

				}
				GRRLIB_SetPixelTotexImg(w, h, tex_bloom, write.rgba);
			}
		}
		//fprintf(file, "done with a loop\n");
		fclose(file);

		GRRLIB_FlushTex(tex_bloom);
		GRRLIB_SetBlend(GRRLIB_BLEND_ADD);
		GRRLIB_DrawImgQuad(screen_quad, tex_bloom, 0xFFFFFFFF);
		GRRLIB_SetBlend(GRRLIB_BLEND_ALPHA);
	}

}

void closeBloom() {
	free(tex_bloom);
	free(tex_screen);
}

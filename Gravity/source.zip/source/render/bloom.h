/*
 * bloom.h
 *
 *  Created on: Mar 26, 2011
 *      Author: hopwoocp
 */

#ifndef BLOOM_H_
#define BLOOM_H_

#endif /* BLOOM_H_ */
// Storage to capture the rendered scene
GRRLIB_texImg *tex_screen;

// Storage for the bloom texture
GRRLIB_texImg *tex_bloom;

// You can tweak these next five constants...
#define BLOOM_WIDTH_SCALE 4
#define BLOOM_HEIGHT_SCALE 4
#define BLOOM_RADIUS 6 // Works best as an odd number
#define BLOOM_THRESHOLD 170 // 0 -> 255
#define BLOOM_ALPHA 0x55

// ...But you should leave these alone!
#define BLUR_STACK_LEFT ( ( BLOOM_RADIUS + 1) /2)
#define BLUR_STACK_RIGHT ( ( BLOOM_RADIUS - 1) /2)
#define BLOOM_TEX_WIDTH ( 640 / BLOOM_WIDTH_SCALE )
#define BLOOM_TEX_HEIGHT ( 480 / BLOOM_HEIGHT_SCALE )
#define BLOOM_STACK_LOOKUP_SIZE ( ( UINT8_MAX * BLOOM_RADIUS ) + 1 )

void closeBloom();
void doBloom();
static inline u32 _GetPixel(const int x, const int y, const GRRLIB_texImg *tex);
void initializeBloom();

/*
 * fps.h
 *
 *  Created on: Mar 3, 2011
 *      Author: hopwoocp
 */

#ifndef FPS_H_
#define FPS_H_


#endif /* FPS_H_ */

u8 calculateFPS();
u64 profiler(int start);

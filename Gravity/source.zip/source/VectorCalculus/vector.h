/*
 * vector.h
 *
 *  Created on: Mar 4, 2011
 *      Author: hopwoocp
 */

#ifndef VECTOR_H_
#define VECTOR_H_

#endif /* VECTOR_H_ */

float dotProductVelocities(Ship * ship, Bullet * bullet);

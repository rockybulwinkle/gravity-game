/*
 * sdcardMount.h
 *
 *  Created on: Apr 1, 2011
 *      Author: Arikado
 */

#ifndef SDCARDMOUNT_H_
#define SDCARDMOUNT_H_
void InitSD();
void DeInitSD();
#endif /* SDCARDMOUNT_H_ */



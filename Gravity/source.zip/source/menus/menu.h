/*
 * menu.h
 *
 *  Created on: Mar 7, 2011
 *      Author: hopwoocp
 */

#ifndef MENU_H_
#define MENU_H_

#endif /* MENU_H_ */
int mainMenu();
